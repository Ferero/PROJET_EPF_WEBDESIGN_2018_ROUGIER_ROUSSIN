(function(){
	angular.module('store', []);
})();

//Controller permettant de gerer l'affichage du quizz, l'enregistrement des reponses
//Et le choix des merveilles.
(function(){
	angular.module('store')
	.controller('storeController',function(){
		this.reponse = 0;
		this.question = 0;
		this.infoQuestion=[];
		this.merveille="un truc";
		this.img = "rien";

		//Methode permettant de passer a la question suivante
		this.changeQuestion=function(){
			this.question++;
		};

		//Methode permettant d'enregistrer une reponse
		this.changeRep=function(rep,bool){
			if(bool){
				this.reponse = rep;
				console.log(this.reponse);
			}
			else{
				this.reponse = 0;
				console.log(this.reponse);
			}
		};

		//Methode permettant de stocker la reponse enregistree dans une liste
		this.on_submit=function(){
			this.infoQuestion.push(this.reponse);
			this.reponse = 0;
			console.log(this.infoQuestion);
		};

		//Methode permettant de choisir une merveille en fonction des reponses
		this.results=function(){
			var res = 0;
			for (var i = 0; i < 10; i++) {
				res= res + this.infoQuestion[i];
			}

			console.log(res);

			if (res == 10) {this.merveille = "La Grande Muraille de Chine"; this.img = "Muraille.jpg";}
			if (res == 11) {this.merveille = "Pétra";this.img += "Petra.jpg";}
			if (res == 12) {this.merveille = "Le Christ Rédempteur";this.img = "Christ.jpg";}
			if (res == 13) {this.merveille = "Le Machu Picchu";this.img = "MachuPicchu.jpg";}
			if (res == 14) {this.merveille = "Chichen Itza";this.img = "ChichenItza.jpg";}
			if (res == 15) {this.merveille = "Le Colisée";this.img = "Colisée.jpg";}
			if (res == 16) {this.merveille = "Le Taj Mahal";this.img = "TajMahal.jpg";}
			if (res == 17 || res == 18) {this.merveille = "La Pyramide de Khéops";this.img = "kheops.jpg";}
			if (res == 19 || res == 20) {this.merveille = "Les Jardins Suspendus de Babylone";this.img = "babylone.jpg";}
			if (res == 21 || res == 22) {this.merveille = "La Statue Chryséléphantine de Zeus";this.img = "zeus.jpg";}
			if (res == 23 || res == 24) {this.merveille = "Mausolée d'Halicarnasse";this.img = "halicarnasse.jpg";}
			if (res == 25 || res == 26) {this.merveille = "Le Temple d'Artémis";this.img = "artemis.jpg";}
			if (res == 27 || res == 28) {this.merveille = "Le Colosse de Rhodes";this.img = "colosse.jpg";}
			if (res == 29 || res == 30) {this.merveille = "Le Phare d'Alexandrie";this.img = "alexandrie.jpg";}
			return this.merveille;
		};
	});
})();