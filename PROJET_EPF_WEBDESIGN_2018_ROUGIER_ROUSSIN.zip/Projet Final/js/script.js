(function(){
	angular.module('store', []);
})();

//Controller permettant de charger les données des anciennes merveilles du fichier JSON 
//Ainsi que de gerer l'affichage du contenu des onglets de navigations. 
(function(){
	angular.module('store')
	.controller('storeController', ['$scope', '$http', function($scope, $http){
		this.selectedTab = -1;
		var _this=this;
		this.infoList=[];

		$http.get("./data/data.json").then(function(data) {
    		_this.infoList=data.data[0];
		});

		//Methode permettant de gerer l'affichage du contenu des onglets de navigations
		this.selectTab = function(id){
			if (id == this.selectedTab) this.selectedTab = -1;
			else this.selectedTab = id; 

			
    		$scope.img = _this.infoList[id-1].img;
        	$scope.name = _this.infoList[id-1].name;
        	$scope.dateConstruction = _this.infoList[id-1].dateConstruction;
        	$scope.dateDestruction = _this.infoList[id-1].dateDestruction;
        	$scope.Lieu = _this.infoList[id-1].Lieu;
        	$scope.maitreOuvrage = _this.infoList[id-1].maitreOuvrage;
        	$scope.Description = _this.infoList[id-1].Description;
		
		};	
	}]);
})();

//Controller permettant de charger les données des nouvelles merveilles du fichier JSON
//Ainsi que de gerer l'affichage du contenu des onglets de navigations
(function(){
	angular.module('store')
	.controller('storeController2', ['$scope', '$http', function($scope, $http){
		this.selectedTab = -1;
		var _this=this;
		this.infoList=[];

		$http.get("./data/data.json").then(function(data) {
    		_this.infoList=data.data[1];
		});

		//Methode permettant de gerer l'affichage du contenu des onglets de navigations
		this.selectTab = function(id){
			if (id == this.selectedTab) this.selectedTab = -1;
			else this.selectedTab = id; 

			
    		$scope.img = _this.infoList[id-1].img;
        	$scope.name = _this.infoList[id-1].name;
        	$scope.dateConstruction = _this.infoList[id-1].dateConstruction;
        	$scope.Lieu = _this.infoList[id-1].Lieu;
        	$scope.maitreOuvrage = _this.infoList[id-1].maitreOuvrage;
        	$scope.Description = _this.infoList[id-1].Description;
		
		};	
	}]);
})();






